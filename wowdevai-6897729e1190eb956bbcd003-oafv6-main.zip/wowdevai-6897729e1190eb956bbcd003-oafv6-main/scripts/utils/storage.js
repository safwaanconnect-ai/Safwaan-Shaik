export class LocalStorageManager {
  constructor() {
    this.prefix = 'wowdevai_';
    this.initializeStorage();
  }

  initializeStorage() {
    // Check if localStorage is available
    if (!this.isStorageAvailable()) {
      console.warn('LocalStorage is not available, using memory storage');
      this.memoryStorage = new Map();
    }

    // Initialize IndexedDB for large files
    this.initializeIndexedDB();
  }

  isStorageAvailable() {
    try {
      const test = 'storage-test';
      localStorage.setItem(test, test);
      localStorage.removeItem(test);
      return true;
    } catch (e) {
      return false;
    }
  }

  async initializeIndexedDB() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        resolve(false);
        return;
      }

      const request = indexedDB.open('WowDevAI', 1);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve(true);
      };
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        // Store for large files (IPA, APK)
        if (!db.objectStoreNames.contains('files')) {
          const fileStore = db.createObjectStore('files', { keyPath: 'id' });
          fileStore.createIndex('name', 'name', { unique: false });
          fileStore.createIndex('type', 'type', { unique: false });
        }
        
        // Store for AI conversations
        if (!db.objectStoreNames.contains('conversations')) {
          const convStore = db.createObjectStore('conversations', { keyPath: 'id' });
          convStore.createIndex('timestamp', 'timestamp', { unique: false });
        }
        
        // Store for generated content
        if (!db.objectStoreNames.contains('generated')) {
          const genStore = db.createObjectStore('generated', { keyPath: 'id' });
          genStore.createIndex('type', 'type', { unique: false });
          genStore.createIndex('timestamp', 'timestamp', { unique: false });
        }
      };
    });
  }

  // LocalStorage methods
  setItem(key, value) {
    const fullKey = this.prefix + key;
    const data = {
      value,
      timestamp: Date.now(),
      expires: null
    };

    try {
      if (this.isStorageAvailable()) {
        localStorage.setItem(fullKey, JSON.stringify(data));
      } else {
        this.memoryStorage.set(fullKey, data);
      }
    } catch (error) {
      console.error('Failed to save to storage:', error);
      throw error;
    }
  }

  getItem(key, defaultValue = null) {
    const fullKey = this.prefix + key;
    
    try {
      let data;
      if (this.isStorageAvailable()) {
        const stored = localStorage.getItem(fullKey);
        data = stored ? JSON.parse(stored) : null;
      } else {
        data = this.memoryStorage.get(fullKey) || null;
      }

      if (!data) return defaultValue;
      
      // Check expiration
      if (data.expires && Date.now() > data.expires) {
        this.removeItem(key);
        return defaultValue;
      }

      return data.value;
    } catch (error) {
      console.error('Failed to get from storage:', error);
      return defaultValue;
    }
  }

  removeItem(key) {
    const fullKey = this.prefix + key;
    
    try {
      if (this.isStorageAvailable()) {
        localStorage.removeItem(fullKey);
      } else {
        this.memoryStorage.delete(fullKey);
      }
    } catch (error) {
      console.error('Failed to remove from storage:', error);
    }
  }

  clear() {
    try {
      if (this.isStorageAvailable()) {
        const keys = Object.keys(localStorage);
        keys.forEach(key => {
          if (key.startsWith(this.prefix)) {
            localStorage.removeItem(key);
          }
        });
      } else {
        this.memoryStorage.clear();
      }
    } catch (error) {
      console.error('Failed to clear storage:', error);
    }
  }

  // IndexedDB methods for large files
  async storeFile(file, metadata = {}) {
    if (!this.db) throw new Error('IndexedDB not available');

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['files'], 'readwrite');
      const store = transaction.objectStore('files');
      
      const fileData = {
        id: this.generateId(),
        name: file.name,
        type: file.type,
        size: file.size,
        data: file,
        metadata,
        timestamp: Date.now()
      };

      const request = store.add(fileData);
      request.onsuccess = () => resolve(fileData.id);
      request.onerror = () => reject(request.error);
    });
  }

  async getFile(id) {
    if (!this.db) throw new Error('IndexedDB not available');

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['files'], 'readonly');
      const store = transaction.objectStore('files');
      
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async deleteFile(id) {
    if (!this.db) throw new Error('IndexedDB not available');

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['files'], 'readwrite');
      const store = transaction.objectStore('files');
      
      const request = store.delete(id);
      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });
  }

  async getAllFiles() {
    if (!this.db) throw new Error('IndexedDB not available');

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['files'], 'readonly');
      const store = transaction.objectStore('files');
      
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // Conversation storage
  async storeConversation(messages, metadata = {}) {
    if (!this.db) {
      // Fallback to localStorage for small conversations
      const conversations = this.getItem('conversations', []);
      const conversation = {
        id: this.generateId(),
        messages,
        metadata,
        timestamp: Date.now()
      };
      conversations.push(conversation);
      this.setItem('conversations', conversations);
      return conversation.id;
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['conversations'], 'readwrite');
      const store = transaction.objectStore('conversations');
      
      const conversation = {
        id: this.generateId(),
        messages,
        metadata,
        timestamp: Date.now()
      };

      const request = store.add(conversation);
      request.onsuccess = () => resolve(conversation.id);
      request.onerror = () => reject(request.error);
    });
  }

  async getConversation(id) {
    if (!this.db) {
      const conversations = this.getItem('conversations', []);
      return conversations.find(conv => conv.id === id);
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['conversations'], 'readonly');
      const store = transaction.objectStore('conversations');
      
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // Utility methods
  getStorageUsage() {
    let used = 0;
    let quota = 5; // 5MB default for localStorage

    try {
      if (this.isStorageAvailable()) {
        // Calculate localStorage usage
        for (let key in localStorage) {
          if (key.startsWith(this.prefix)) {
            used += localStorage[key].length;
          }
        }
        used = Math.round(used / 1024 / 1024 * 100) / 100; // Convert to MB
      }

      // Check navigator storage API for more accurate quota
      if ('storage' in navigator && 'estimate' in navigator.storage) {
        navigator.storage.estimate().then(estimate => {
          quota = Math.round(estimate.quota / 1024 / 1024);
          used = Math.round(estimate.usage / 1024 / 1024 * 100) / 100;
        });
      }
    } catch (error) {
      console.error('Failed to calculate storage usage:', error);
    }

    return { used, quota };
  }

  generateId() {
    return 'id_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
  }

  // Export/Import functionality
  async exportData() {
    const data = {
      localStorage: {},
      indexedDB: {
        files: [],
        conversations: [],
        generated: []
      },
      timestamp: Date.now(),
      version: '1.0'
    };

    // Export localStorage data
    if (this.isStorageAvailable()) {
      for (let key in localStorage) {
        if (key.startsWith(this.prefix)) {
          data.localStorage[key] = localStorage[key];
        }
      }
    }

    // Export IndexedDB data
    if (this.db) {
      try {
        data.indexedDB.files = await this.getAllFiles();
        // Add other stores as needed
      } catch (error) {
        console.error('Failed to export IndexedDB data:', error);
      }
    }

    return data;
  }

  async importData(data) {
    if (!data || data.version !== '1.0') {
      throw new Error('Invalid or incompatible data format');
    }

    // Import localStorage data
    if (data.localStorage && this.isStorageAvailable()) {
      for (let key in data.localStorage) {
        localStorage.setItem(key, data.localStorage[key]);
      }
    }

    // Import IndexedDB data
    if (data.indexedDB && this.db) {
      // Clear existing data first
      await this.clearIndexedDB();
      
      // Import files
      for (let fileData of data.indexedDB.files) {
        await new Promise((resolve, reject) => {
          const transaction = this.db.transaction(['files'], 'readwrite');
          const store = transaction.objectStore('files');
          const request = store.add(fileData);
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        });
      }
    }
  }

  async clearIndexedDB() {
    if (!this.db) return;

    const stores = ['files', 'conversations', 'generated'];
    
    for (let storeName of stores) {
      await new Promise((resolve, reject) => {
        const transaction = this.db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.clear();
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }
}