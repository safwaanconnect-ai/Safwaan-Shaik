import { LocalStorageManager } from './utils/storage.js';
import { AIManager } from './utils/ai.js';
import { TerminalManager } from './utils/terminal.js';
import { FileManager } from './utils/files.js';

class WowDevAIApp {
  constructor() {
    this.storage = new LocalStorageManager();
    this.ai = new AIManager();
    this.terminal = new TerminalManager();
    this.fileManager = new FileManager();
    
    this.initializeEventListeners();
    this.loadStoredConfiguration();
  }

  initializeEventListeners() {
    // Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuBtn && mobileMenu) {
      mobileMenuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
      });
    }

    // API configuration
    const saveConfigBtn = document.getElementById('save-config-btn');
    if (saveConfigBtn) {
      saveConfigBtn.addEventListener('click', () => this.saveAPIConfiguration());
    }

    // Quick actions
    this.setupQuickActions();
    
    // Modals
    this.setupModals();
    
    // Storage status
    this.updateStorageStatus();
  }

  setupQuickActions() {
    // Chat action
    const chatAction = document.querySelector('[data-id="action-chat"]');
    if (chatAction) {
      chatAction.addEventListener('click', () => this.openChatModal());
    }

    // Terminal action
    const terminalAction = document.querySelector('[data-id="action-terminal"]');
    const terminalBtn = document.getElementById('terminal-btn');
    
    [terminalAction, terminalBtn].forEach(btn => {
      if (btn) {
        btn.addEventListener('click', () => this.openTerminalModal());
      }
    });

    // File editor action
    const fileAction = document.querySelector('[data-id="action-edit-files"]');
    if (fileAction) {
      fileAction.addEventListener('click', () => window.location.href = 'files.html');
    }

    // Generate action
    const generateAction = document.querySelector('[data-id="action-generate"]');
    if (generateAction) {
      generateAction.addEventListener('click', () => window.location.href = 'generate.html');
    }
  }

  setupModals() {
    // Chat modal
    const chatModal = document.getElementById('chat-modal');
    const closeChatModal = document.getElementById('close-chat-modal');
    const sendChatBtn = document.getElementById('send-chat-btn');
    const chatInput = document.getElementById('chat-input');

    if (closeChatModal) {
      closeChatModal.addEventListener('click', () => {
        chatModal.classList.add('hidden');
      });
    }

    if (sendChatBtn && chatInput) {
      sendChatBtn.addEventListener('click', () => this.sendChatMessage());
      chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') this.sendChatMessage();
      });
    }

    // Terminal modal
    const terminalModal = document.getElementById('terminal-modal');
    const closeTerminalModal = document.getElementById('close-terminal-modal');
    const terminalInput = document.getElementById('terminal-input');

    if (closeTerminalModal) {
      closeTerminalModal.addEventListener('click', () => {
        terminalModal.classList.add('hidden');
      });
    }

    if (terminalInput) {
      terminalInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') this.executeTerminalCommand();
      });
    }
  }

  openChatModal() {
    const modal = document.getElementById('chat-modal');
    if (modal) {
      modal.classList.remove('hidden');
    }
  }

  openTerminalModal() {
    const modal = document.getElementById('terminal-modal');
    if (modal) {
      modal.classList.remove('hidden');
      this.terminal.initialize(document.getElementById('terminal-output'));
    }
  }

  async sendChatMessage() {
    const input = document.getElementById('chat-input');
    const messagesContainer = document.getElementById('chat-messages');
    
    if (!input || !messagesContainer || !input.value.trim()) return;

    const message = input.value.trim();
    input.value = '';

    // Add user message
    this.addChatMessage('user', message, messagesContainer);

    // Get AI response
    try {
      const response = await this.ai.generateResponse(message);
      this.addChatMessage('assistant', response, messagesContainer);
    } catch (error) {
      this.addChatMessage('system', 'Error: ' + error.message, messagesContainer);
    }
  }

  addChatMessage(role, content, container) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `flex ${role === 'user' ? 'justify-end' : 'justify-start'}`;
    
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = `max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
      role === 'user' 
        ? 'bg-ai-purple text-white' 
        : role === 'assistant'
        ? 'bg-gray-700 text-white'
        : 'bg-red-600 text-white'
    }`;
    bubbleDiv.textContent = content;
    
    messageDiv.appendChild(bubbleDiv);
    container.appendChild(messageDiv);
    container.scrollTop = container.scrollHeight;
  }

  executeTerminalCommand() {
    const input = document.getElementById('terminal-input');
    const output = document.getElementById('terminal-output');
    
    if (!input || !output) return;

    const command = input.value.trim();
    if (!command) return;

    input.value = '';
    this.terminal.executeCommand(command, output);
  }

  saveAPIConfiguration() {
    const config = {
      openai: document.getElementById('openai-key')?.value,
      claude: document.getElementById('claude-key')?.value,
      gemini: document.getElementById('gemini-key')?.value,
      customEndpoint: document.getElementById('custom-endpoint')?.value,
      timestamp: Date.now()
    };

    this.storage.setItem('apiConfig', config);
    
    // Update AI manager with new config
    this.ai.updateConfiguration(config);
    
    // Show success message
    this.showNotification('Configuration saved successfully!', 'success');
  }

  loadStoredConfiguration() {
    const config = this.storage.getItem('apiConfig');
    if (!config) return;

    // Populate form fields
    if (config.openai) {
      const openaiInput = document.getElementById('openai-key');
      if (openaiInput) openaiInput.value = config.openai;
    }

    if (config.claude) {
      const claudeInput = document.getElementById('claude-key');
      if (claudeInput) claudeInput.value = config.claude;
    }

    if (config.gemini) {
      const geminiInput = document.getElementById('gemini-key');
      if (geminiInput) geminiInput.value = config.gemini;
    }

    if (config.customEndpoint) {
      const customInput = document.getElementById('custom-endpoint');
      if (customInput) customInput.value = config.customEndpoint;
    }

    // Update AI manager
    this.ai.updateConfiguration(config);
  }

  updateStorageStatus() {
    const statusBtn = document.getElementById('storage-status');
    if (!statusBtn) return;

    const usage = this.storage.getStorageUsage();
    const statusText = statusBtn.querySelector('span');
    
    if (statusText) {
      statusText.textContent = `${usage.used}MB / ${usage.quota}MB`;
    }

    // Update color based on usage
    const percentage = (usage.used / usage.quota) * 100;
    if (percentage > 80) {
      statusBtn.className = statusBtn.className.replace('bg-gray-800', 'bg-red-600');
    } else if (percentage > 60) {
      statusBtn.className = statusBtn.className.replace('bg-gray-800', 'bg-yellow-600');
    }
  }

  showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg text-white z-50 ${
      type === 'success' ? 'bg-green-600' : 
      type === 'error' ? 'bg-red-600' : 
      'bg-blue-600'
    }`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
      notification.remove();
    }, 3000);
  }
}

export function initializeApp() {
  // Wait for DOM to be ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      new WowDevAIApp();
    });
  } else {
    new WowDevAIApp();
  }
}