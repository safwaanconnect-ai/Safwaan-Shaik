export async function loadComponent(selector) {
  const container = document.querySelector(selector);
  if (!container) return;
  
  const source = container.dataset.source;
  if (!source) return;
  
  try {
    const response = await fetch(window.location.origin + '/api/preview-6897729e1190eb956bbcd003/' + source);
    const html = await response.text();
    container.innerHTML = html;
  } catch (error) {
    console.error('Failed to load component:', source, error);
  }
}

export function createComponent(tag, attributes = {}, children = []) {
  const element = document.createElement(tag);
  
  // Set attributes
  Object.entries(attributes).forEach(([key, value]) => {
    element.setAttribute(key, value);
  });
  
  // Add children
  children.forEach(child => {
    if (typeof child === 'string') {
      element.appendChild(document.createTextNode(child));
    } else {
      element.appendChild(child);
    }
  });
  
  return element;
}