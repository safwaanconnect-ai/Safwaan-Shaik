# Safwaan Connect Mobile

A cross-platform React Native mobile app built with Expo and Supabase.

## Features

- 🔐 **Authentication**: Email/password and Google OAuth
- 🎨 **Theming**: Light/dark mode with system preference support
- 📱 **Navigation**: Bottom tab navigation (Home, Profile, Settings)
- 🔥 **Backend**: Supabase integration for auth and data
- ✅ **Testing**: Jest + React Native Testing Library
- 🚀 **Cross-platform**: iOS, Android, and Web support

## Getting Started

### Prerequisites

- Node.js 16.x or later
- npm or yarn
- Expo CLI (`npm install -g @expo/cli`)
- iOS Simulator (for iOS development)
- Android Studio & Android Emulator (for Android development)

### Installation

1. Navigate to the mobile directory:
   ```bash
   cd mobile
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up Supabase:
   - Create a new project at [supabase.com](https://supabase.com)
   - Get your project URL and anon key
   - Update `src/services/supabase.ts` with your credentials

4. Create the profiles table in Supabase:
   ```sql
   CREATE TABLE profiles (
     id UUID REFERENCES auth.users ON DELETE CASCADE,
     full_name TEXT,
     avatar_url TEXT,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
     updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
     PRIMARY KEY (id)
   );
   
   -- Enable Row Level Security
   ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
   
   -- Create policies
   CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id);
   CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
   CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
   ```

### Running the App

Start the development server:
```bash
npm start
```

This will open Expo DevTools in your browser. From there you can:

- Press `i` to run on iOS Simulator
- Press `a` to run on Android Emulator  
- Press `w` to run on Web
- Scan the QR code with Expo Go app on your physical device

### Platform-Specific Commands

Run on specific platforms:

```bash
# iOS
npm run ios

# Android  
npm run android

# Web
npm run web
```

## Project Structure

```
src/
├── components/          # Reusable UI components
│   └── Button.tsx
├── contexts/           # React Context providers
│   ├── AuthContext.tsx
│   └── ThemeContext.tsx
├── navigation/         # Navigation configuration
│   └── AppNavigator.tsx
├── screens/           # Screen components
│   ├── AuthScreen.tsx
│   ├── HomeScreen.tsx
│   ├── ProfileScreen.tsx
│   ├── SettingsScreen.tsx
│   └── LoadingScreen.tsx
├── services/          # External service integrations
│   └── supabase.ts
└── __tests__/         # Test files
    ├── components/
    ├── contexts/
    └── screens/
```

## Testing

Run the test suite:

```bash
# Run tests once
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm run test:coverage
```

## Building for Production

### Using Expo Build Service (EAS)

1. Install EAS CLI:
   ```bash
   npm install -g @expo/eas-cli
   ```

2. Configure EAS:
   ```bash
   eas build:configure
   ```

3. Build for platforms:
   ```bash
   # Android APK
   eas build --platform android --profile preview

   # iOS for TestFlight/App Store
   eas build --platform ios --profile production

   # Build for both platforms
   eas build --platform all
   ```

### Web Deployment

Build for web:
```bash
npm run build:web
```

This creates a `web-build` directory that can be deployed to any static hosting service.

## Environment Variables

Create a `.env` file in the mobile directory:

```env
EXPO_PUBLIC_SUPABASE_URL=your_supabase_url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Features Overview

### Authentication
- Email/password sign up and sign in
- Google OAuth integration
- Persistent sessions with AsyncStorage
- Profile management

### Theme System
- Light/dark/system themes
- Persistent theme preferences
- Context-based color system
- Automatic system theme detection

### Navigation
- Bottom tab navigation
- Stack navigation for auth flow
- Theme-aware navigation styling
- Icon-based tab indicators

## Contributing

1. Create a feature branch
2. Make your changes
3. Add/update tests
4. Run the test suite
5. Submit a pull request

## Troubleshooting

### Common Issues

1. **Metro bundler cache issues**:
   ```bash
   npx expo start --clear
   ```

2. **iOS build issues**:
   ```bash
   cd ios && pod install && cd ..
   ```

3. **Android issues**:
   - Ensure Android SDK is properly installed
   - Check Android emulator is running
   - Verify ANDROID_HOME environment variable

4. **Supabase connection issues**:
   - Verify your Supabase URL and keys
   - Check network connectivity
   - Ensure RLS policies are configured correctly

## License

MIT License - see LICENSE file for details.