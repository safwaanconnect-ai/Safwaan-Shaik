import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import { View, Text, TouchableOpacity } from 'react-native';
import { ThemeProvider, useTheme } from '../../contexts/ThemeContext';

const TestComponent = () => {
  const { theme, setTheme, isDarkMode, colors } = useTheme();

  return (
    <View>
      <Text testID="theme">{theme}</Text>
      <Text testID="isDarkMode">{isDarkMode.toString()}</Text>
      <Text testID="backgroundColor" style={{ backgroundColor: colors.background }}>
        Background
      </Text>
      <TouchableOpacity testID="setLight" onPress={() => setTheme('light')}>
        <Text>Set Light</Text>
      </TouchableOpacity>
      <TouchableOpacity testID="setDark" onPress={() => setTheme('dark')}>
        <Text>Set Dark</Text>
      </TouchableOpacity>
    </View>
  );
};

describe('ThemeContext', () => {
  it('provides default theme', () => {
    const { getByTestId } = render(
      <ThemeProvider>
        <TestComponent />
      </ThemeProvider>
    );

    expect(getByTestId('theme').props.children).toBe('auto');
  });

  it('allows theme changes', () => {
    const { getByTestId } = render(
      <ThemeProvider>
        <TestComponent />
      </ThemeProvider>
    );

    fireEvent.press(getByTestId('setLight'));
    expect(getByTestId('theme').props.children).toBe('light');

    fireEvent.press(getByTestId('setDark'));
    expect(getByTestId('theme').props.children).toBe('dark');
  });

  it('provides color values', () => {
    const { getByTestId } = render(
      <ThemeProvider>
        <TestComponent />
      </ThemeProvider>
    );

    const backgroundText = getByTestId('backgroundColor');
    expect(backgroundText.props.style.backgroundColor).toBeDefined();
  });
});