import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import Button from '../../components/Button';
import { ThemeProvider } from '../../contexts/ThemeContext';

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <ThemeProvider>{children}</ThemeProvider>
);

describe('Button Component', () => {
  it('renders correctly with default props', () => {
    const { getByText } = render(
      <TestWrapper>
        <Button title="Test Button" onPress={() => {}} />
      </TestWrapper>
    );

    expect(getByText('Test Button')).toBeTruthy();
  });

  it('calls onPress when pressed', () => {
    const mockPress = jest.fn();
    const { getByText } = render(
      <TestWrapper>
        <Button title="Test Button" onPress={mockPress} />
      </TestWrapper>
    );

    fireEvent.press(getByText('Test Button'));
    expect(mockPress).toHaveBeenCalledTimes(1);
  });

  it('does not call onPress when disabled', () => {
    const mockPress = jest.fn();
    const { getByText } = render(
      <TestWrapper>
        <Button title="Test Button" onPress={mockPress} disabled={true} />
      </TestWrapper>
    );

    fireEvent.press(getByText('Test Button'));
    expect(mockPress).not.toHaveBeenCalled();
  });

  it('shows loading indicator when loading', () => {
    const { queryByText, UNSAFE_getByType } = render(
      <TestWrapper>
        <Button title="Test Button" onPress={() => {}} loading={true} />
      </TestWrapper>
    );

    expect(queryByText('Test Button')).toBeNull();
    expect(UNSAFE_getByType('ActivityIndicator')).toBeTruthy();
  });
});