import React from 'react';
import { render } from '@testing-library/react-native';
import HomeScreen from '../../screens/HomeScreen';
import { ThemeProvider } from '../../contexts/ThemeContext';
import { AuthProvider } from '../../contexts/AuthContext';

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <ThemeProvider>
    <AuthProvider>{children}</AuthProvider>
  </ThemeProvider>
);

describe('HomeScreen', () => {
  it('renders welcome message', () => {
    const { getByText } = render(
      <TestWrapper>
        <HomeScreen />
      </TestWrapper>
    );

    expect(getByText(/Good/)).toBeTruthy(); // Matches "Good Morning", "Good Afternoon", etc.
  });

  it('displays quick actions', () => {
    const { getByText } = render(
      <TestWrapper>
        <HomeScreen />
      </TestWrapper>
    );

    expect(getByText('Quick Actions')).toBeTruthy();
    expect(getByText('Notifications')).toBeTruthy();
    expect(getByText('Messages')).toBeTruthy();
    expect(getByText('Calendar')).toBeTruthy();
    expect(getByText('Favorites')).toBeTruthy();
  });

  it('shows user stats', () => {
    const { getByText } = render(
      <TestWrapper>
        <HomeScreen />
      </TestWrapper>
    );

    expect(getByText('Your Stats')).toBeTruthy();
    expect(getByText('Connections')).toBeTruthy();
    expect(getByText('Days Active')).toBeTruthy();
    expect(getByText('Messages')).toBeTruthy();
  });
});