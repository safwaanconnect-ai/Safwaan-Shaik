import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { useTheme, Theme } from '../contexts/ThemeContext';

export default function SettingsScreen() {
  const { theme, setTheme, isDarkMode, colors } = useTheme();

  const handleThemeChange = (newTheme: Theme) => {
    setTheme(newTheme);
  };

  const handleContactSupport = () => {
    Alert.alert(
      'Contact Support',
      'Please email us at support@safwaanconnect.com',
      [{ text: 'OK' }]
    );
  };

  const handleRateApp = () => {
    Alert.alert(
      'Rate App',
      'Thank you for wanting to rate our app! This would redirect to the app store.',
      [{ text: 'OK' }]
    );
  };

  const handleShareApp = () => {
    Alert.alert(
      'Share App',
      'Share Safwaan Connect with your friends!',
      [{ text: 'OK' }]
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.content}>
        {/* Appearance Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            Appearance
          </Text>
          
          <View style={[styles.settingGroup, { backgroundColor: colors.surface }]}>
            <TouchableOpacity
              style={[styles.settingItem, theme === 'light' && styles.selectedSetting]}
              onPress={() => handleThemeChange('light')}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="sunny" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Light Mode
                </Text>
              </View>
              {theme === 'light' && (
                <Ionicons name="checkmark" size={20} color={colors.primary} />
              )}
            </TouchableOpacity>

            <View style={[styles.separator, { backgroundColor: colors.border }]} />

            <TouchableOpacity
              style={[styles.settingItem, theme === 'dark' && styles.selectedSetting]}
              onPress={() => handleThemeChange('dark')}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="moon" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Dark Mode
                </Text>
              </View>
              {theme === 'dark' && (
                <Ionicons name="checkmark" size={20} color={colors.primary} />
              )}
            </TouchableOpacity>

            <View style={[styles.separator, { backgroundColor: colors.border }]} />

            <TouchableOpacity
              style={[styles.settingItem, theme === 'auto' && styles.selectedSetting]}
              onPress={() => handleThemeChange('auto')}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="phone-portrait" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  System Default
                </Text>
              </View>
              {theme === 'auto' && (
                <Ionicons name="checkmark" size={20} color={colors.primary} />
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* Notifications Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            Notifications
          </Text>
          
          <View style={[styles.settingGroup, { backgroundColor: colors.surface }]}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="notifications" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Push Notifications
                </Text>
              </View>
              <Switch
                value={true}
                onValueChange={() => {}}
                trackColor={{ false: colors.border, true: colors.primary + '40' }}
                thumbColor={colors.primary}
              />
            </View>

            <View style={[styles.separator, { backgroundColor: colors.border }]} />

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="mail" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Email Notifications
                </Text>
              </View>
              <Switch
                value={false}
                onValueChange={() => {}}
                trackColor={{ false: colors.border, true: colors.primary + '40' }}
                thumbColor={colors.textSecondary}
              />
            </View>

            <View style={[styles.separator, { backgroundColor: colors.border }]} />

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="volume-high" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Sound & Vibration
                </Text>
              </View>
              <Switch
                value={true}
                onValueChange={() => {}}
                trackColor={{ false: colors.border, true: colors.primary + '40' }}
                thumbColor={colors.primary}
              />
            </View>
          </View>
        </View>

        {/* Privacy Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            Privacy & Security
          </Text>
          
          <View style={[styles.settingGroup, { backgroundColor: colors.surface }]}>
            <TouchableOpacity style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="lock-closed" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Privacy Policy
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.textSecondary} />
            </TouchableOpacity>

            <View style={[styles.separator, { backgroundColor: colors.border }]} />

            <TouchableOpacity style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="document-text" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Terms of Service
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.textSecondary} />
            </TouchableOpacity>

            <View style={[styles.separator, { backgroundColor: colors.border }]} />

            <TouchableOpacity style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="shield-checkmark" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Data & Storage
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.textSecondary} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Support Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            Support
          </Text>
          
          <View style={[styles.settingGroup, { backgroundColor: colors.surface }]}>
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={handleContactSupport}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="help-circle" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Contact Support
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.textSecondary} />
            </TouchableOpacity>

            <View style={[styles.separator, { backgroundColor: colors.border }]} />

            <TouchableOpacity 
              style={styles.settingItem}
              onPress={handleRateApp}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="star" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Rate App
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.textSecondary} />
            </TouchableOpacity>

            <View style={[styles.separator, { backgroundColor: colors.border }]} />

            <TouchableOpacity 
              style={styles.settingItem}
              onPress={handleShareApp}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="share" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Share App
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.textSecondary} />
            </TouchableOpacity>
          </View>
        </View>

        {/* About Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            About
          </Text>
          
          <View style={[styles.settingGroup, { backgroundColor: colors.surface }]}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="information-circle" size={20} color={colors.text} />
                <Text style={[styles.settingText, { color: colors.text }]}>
                  Version
                </Text>
              </View>
              <Text style={[styles.versionText, { color: colors.textSecondary }]}>
                1.0.0
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
  },
  settingGroup: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  selectedSetting: {
    opacity: 0.7,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingText: {
    fontSize: 16,
    marginLeft: 12,
  },
  separator: {
    height: 1,
    marginLeft: 48,
  },
  versionText: {
    fontSize: 14,
  },
});